# Yatharth Payment Module

This module adds:

- Razorpay order creation
- Checkout signature verification
- Razorpay webhook verification
- Payment status synchronization
- Manual CASH payments
- Payment listing and filtering
- Order payment history
- Payment summary for the owner dashboard
- Full and partial Razorpay refunds
- Socket.IO `PAYMENT_UPDATED` events

## Files

```text
controllers/paymentController.js
routes/paymentRoutes.js
routes/paymentWebhookRoutes.js
services/razorpayService.js
```

## Install

From the backend root:

```powershell
npm install razorpay
```

## Environment variables

Add to `.env`:

```env
RAZORPAY_KEY_ID=rzp_test_xxxxxxxxxxxx
RAZORPAY_KEY_SECRET=xxxxxxxxxxxxxxxxxxxx
RAZORPAY_WEBHOOK_SECRET=your_webhook_secret
```

Use Razorpay TEST keys while developing.

## Server integration

The webhook route must be mounted before `express.json()` because the webhook signature is calculated from the raw request body.

```js
const paymentRoutes = require("./routes/paymentRoutes");
const paymentWebhookRoutes = require("./routes/paymentWebhookRoutes");

app.use("/api/payments/webhook", paymentWebhookRoutes);

app.use(express.json());

app.use("/api/payments", paymentRoutes);
```

Do not put the webhook route after a global `app.use(express.json())` unless the server is explicitly configured to preserve the raw body.

## Endpoints

```text
POST /api/payments/razorpay/order
POST /api/payments/razorpay/verify
POST /api/payments/webhook
POST /api/payments/manual
GET  /api/payments/summary
GET  /api/payments/order/:orderId
GET  /api/payments
GET  /api/payments/:id
POST /api/payments/:id/refund
```

## Example: create Razorpay payment

```json
{
  "orderId": 25
}
```

The response contains:

```json
{
  "success": true,
  "payment": {},
  "checkout": {
    "keyId": "rzp_test_...",
    "orderId": "order_...",
    "amount": 42000,
    "currency": "INR"
  }
}
```

The frontend uses `checkout.orderId`, `checkout.amount`, and `checkout.keyId` to open Razorpay Checkout.

## Example: verify checkout

```json
{
  "orderId": 25,
  "razorpay_order_id": "order_...",
  "razorpay_payment_id": "pay_...",
  "razorpay_signature": "..."
}
```

## Example: manual cash payment

```json
{
  "orderId": 25,
  "method": "CASH"
}
```

## Example: refund

Full refund:

```json
{}
```

Partial refund:

```json
{
  "amount": 100
}
```

Amount values exposed by Yatharth are INR rupees. Razorpay internally uses paise for API amounts.
